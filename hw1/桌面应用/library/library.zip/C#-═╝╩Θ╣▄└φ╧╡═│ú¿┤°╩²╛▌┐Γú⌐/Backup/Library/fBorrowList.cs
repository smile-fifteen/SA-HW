using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBorrowList : Form
    {
        
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fBorrowList instance = null;
        public static fBorrowList Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBorrowList();
                }
                return instance;
            }
        }
        private fBorrowList()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBorrowList_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void fBorrowlist_Load(object sender, EventArgs e)
        {
            cmblist.SelectedIndex = 0;
            cmblist.Focus();
        }

      

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (cmblist.SelectedIndex == 0)
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from BRDetail where BookID'" + tbSearch.Text + "'").Tables[0];
            }
            else
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from BRDetail where ReaderXueHao='" + tbSearch.Text + "'").Tables[0];
            }
            
           
          
        }
    }
}