using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fReaderClassify : Form
    {

        //����
        #region ����ʵ�ֵ���ģʽ
        private static fReaderClassify instance = null;
        public static fReaderClassify Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fReaderClassify();
                }
                return instance;
            }
        }
        private fReaderClassify()
        {
            InitializeComponent();
            instance = this;
        }
        private void fReaderClassify_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        


        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = string.Empty;
                
                    sql = "INSERT INTO ReaderClassify(Classifyname,SumofBook,SumofDate) VALUES ('" + tbdtypename.Text + "','" + tbsumofbook.Text + "','" + tbsumofdate.Text + "')";
               

                Library.ExecuteNoQuery(sql);
                MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from ReaderClassify").Tables[0];
             
            }
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            }
           

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�Ƿ�ȷ��ɾ��������¼��", "ϵͳ��ʾ��", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes)
            {
                Library.ExecuteNoQuery("delete from ReaderClassify where ClassifyID=" + dataGridView1.CurrentRow.Cells["ClassifyID"].Value.ToString());
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from ReaderClassify").Tables[0];
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = string.Empty;
                    sql = "Update ReaderClassify set Classifyname='" + tbdtypename.Text + "',SumofBook='" +
                        tbsumofbook.Text + "',SumofDate='" + tbsumofdate.Text + "' where ClassifyID='" + tbdtypeno.Text + "'";
                         Library.ExecuteNoQuery(sql);
                MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from ReaderClassify").Tables[0];
                }
              
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select * from ReaderClassify").Tables[0];
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Application.Exit();//�˳�
        }

        private void fReaderClassify_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select * from ReaderClassify").Tables[0];
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0 && dataGridView1.CurrentRow.Index >= 0)
            {

                DataGridViewRow dr = dataGridView1.CurrentRow;
                tbdtypeno.Text = dr.Cells["ClassifyID"].Value.ToString();
                tbdtypename.Text = dr.Cells["ClassifyName"].Value.ToString();
                tbsumofbook.Text = dr.Cells["SumofBook"].Value.ToString();
                tbsumofdate.Text = dr.Cells["SumofDate"].Value.ToString();

            }
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {
            tbdtypeno.Text = "";
            tbdtypename.Text = "";
            tbsumofbook.Text = "";
            tbsumofdate.Text = "";

        }
    }
}