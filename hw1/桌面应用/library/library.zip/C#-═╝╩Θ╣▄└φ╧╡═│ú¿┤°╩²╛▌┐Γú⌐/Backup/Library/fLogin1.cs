using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fLogin1 : Form
    {
        public fLogin1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbtgly_CheckedChanged(object sender, EventArgs e)
        {

        }
         int Count;
        
        private void btOK_Click(object sender, EventArgs e)
        {
            string sql = "select AdminPassword from Admin where AdminID= '" + txbUsername.Text + "'";
            DataSet ds = Library.ExecuteDataSet(sql);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["AdminPassword"].ToString() == txbPassword.Text)
                {
                    this.DialogResult = DialogResult.OK;
                   
                    Library.chuanzhi = txbUsername.Text;
                }
               else
                {
                    MessageBox.Show("��������벻��ȷ��", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbPassword.Focus();
                    txbPassword.SelectAll();
                    Count++;
                }

            }
                else
                {
                    MessageBox.Show("������û��������ڣ�", "�Ѻ���ʾ��");
                    txbUsername.Focus();
                   txbUsername.SelectAll();
                    Count++;

                }
                if (Count > 3)
                {
                    MessageBox.Show("��������������3�Σ�ϵͳ���Զ��˳���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Close();
                }
            }

        private void btCancel_Click(object sender, EventArgs e)
        {
         Application.Exit();
        }

        private void fLogin1_Load(object sender, EventArgs e)
        {
          
            Count = 0;
            txbUsername.Focus();
        }
        }

       

        
    }
