using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fFine : Form
    {
       //����
        #region ����ʵ�ֵ���ģʽ
        private static fFine instance = null;
        public static fFine Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fFine();
                }
                return instance;
            }
        }
        private fFine()
        {
            InitializeComponent();
            instance = this;
        }
        private void fFine_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ
        private void btCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            
             try
            {
                string sql = "Update fine set fine='" + tbMoney.Text + "' where ID='1'";
                Library.ExecuteDataSet(sql);
                MessageBox.Show("�޸ĳɹ���", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbMoney.Text = "";
                tbMoney.Focus();
            }
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbMoney.Text = "";
                tbMoney.Focus();
                
            }
            this.DialogResult = DialogResult.OK;        
        }

        private void fFine_Load(object sender, EventArgs e)
        {

        }
    }
}