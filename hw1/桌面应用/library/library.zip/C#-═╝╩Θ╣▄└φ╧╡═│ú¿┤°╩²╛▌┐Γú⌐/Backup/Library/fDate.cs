using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fDate : Form
    {
       
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fDate instance = null;
        public static fDate Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fDate();
                }
                return instance;
            }
        }
        private fDate()
        {
            InitializeComponent();
            instance = this;
        }
        private void fDate_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void fDate_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
           
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookID='" + tbSearch.Text + "' ").Tables[0];
           
            
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string sql = "Update Book set YNDate='��' where BookID='" + tbSearch.Text + "'";
            Library.ExecuteDataSet(sql);
            MessageBox.Show("�ѳɹ�ԤԼ", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

       
    }
}