using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBook : Form
    {
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fBook instance = null;
        public static fBook Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBook();
                }
                return instance;
            }
        }
        private fBook()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBook_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void ShowDetail()
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select BookID,BookName,BookPublish,BookAuthor,PublishTime,ISBN,YNState,BookCount,YNDate from Book").Tables[0];
        }

        private void fBook_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select BookID,BookName,BookPublish,BookAuthor,PublishTime,ISBN,YNState,BookCount,YNDate from Book").Tables[0];
        }

     

        private void tsbChange_Click(object sender, EventArgs e)
        {
            fBookDetail f = new fBookDetail();
            f.Tag = dataGridView1.CurrentRow;
            f.ShowDialog();

            //ˢ��
            if (f.DialogResult == DialogResult.OK)
            {
                ShowDetail();
            }  
            
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�Ƿ�ȷ��ɾ��������¼��", "ϵͳ��ʾ��", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes)
            {
                Library.ExecuteNoQuery("delete from Book where BookID='" + dataGridView1.CurrentRow.Cells["ColumnBookID"].Value.ToString() +"'");
                ShowDetail();
            }
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            ShowDetail();
        }

        private void tsbExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            fBookDetail a = new fBookDetail();
            a.ShowDialog();
            if (a.DialogResult == DialogResult.OK)
            {

                ShowDetail();
            }
        }
        

       
      

       
    }
}