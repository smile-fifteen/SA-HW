using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBookBorrow : Form
    {
       
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fBookBorrow instance = null;
        public static fBookBorrow Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBookBorrow();
                }
                return instance;
            }
        }
        private fBookBorrow()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBookBorrow_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Close();
        }





        private void tbNO_TextChanged(object sender, EventArgs e)
        {
            if (tbNO.Text.Length == 8)
            {
                string sql = "select * from Reader_Classify where ReaderXueHao='" + tbNO.Text + "'";
                DataSet ds = Library.ExecuteDataSet(sql);
                tbName.Text = ds.Tables[0].Rows[0]["ReaderName"].ToString();
                tbMaj.Text = ds.Tables[0].Rows[0]["ReaderMajor"].ToString();
                tbdclasfy.Text = ds.Tables[0].Rows[0]["ReaderType"].ToString();
                textBox2.Text = ds.Tables[0].Rows[0]["SumofBook"].ToString();
                tbjdate.Text = ds.Tables[0].Rows[0]["SumofDate"].ToString();
                string sql1 = "select count(BrdetailID) as shuliang from BRDetail where ReaderXueHao='" + tbNO.Text + "'";
                DataSet ds1 = Library.ExecuteDataSet(sql1);
                tbdhow.Text = ds1.Tables[0].Rows[0]["shuliang"].ToString();
                int s = int.Parse(tbdhow.Text);
                if (s > 0)
                {
                    int i1 = int.Parse(textBox2.Text);

                    int outcome;
                    outcome = i1 - s;
                    textBox1.Text = outcome.ToString();
                    
                }
                dateTimePicker3.Value = dateTimePicker1.Value.AddDays(Convert.ToInt32(tbjdate.Text, 10));
            }
            
            
        }
      

        private void tbsID_TextChanged(object sender, EventArgs e)
        {
            if(tbsID.Text.Length == 5)
            {
                string sql = "select ISBN,BookName from Book where BookID='" + tbsID.Text + "' and YNState='��'";
                DataSet ds = Library.ExecuteDataSet(sql);

                tbsISBN.Text = ds.Tables[0].Rows[0]["ISBN"].ToString();
                tbsName.Text = ds.Tables[0].Rows[0]["BookName"].ToString();
            }
            


        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            int i1 = int.Parse(textBox2.Text);
            if (i1 < 0)
            {
                MessageBox.Show("�Ѿ����������������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
             string sql = "INSERT INTO BRDetail(ReaderXueHao,BookID,BrDate,YinghuanDate) VALUES ('" +
                         tbNO.Text + "','" + tbsID.Text + "','" + dateTimePicker1.Value.ToShortDateString() + "','" + dateTimePicker3.Value.ToShortDateString() + "')";
            Library.ExecuteNoQuery(sql);
            string sql4 = "Update Book set YNState='��' where BookID='" + tbsID.Text + "'";
            Library.ExecuteNoQuery(sql4);
            MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
            string sql2 = "select * from Reader_Classify where ReaderXueHao='" + tbNO.Text + "'";
            DataSet ds = Library.ExecuteDataSet(sql2);
            tbName.Text = ds.Tables[0].Rows[0]["ReaderName"].ToString();
            tbMaj.Text = ds.Tables[0].Rows[0]["ReaderMajor"].ToString();
            tbdclasfy.Text = ds.Tables[0].Rows[0]["ReaderType"].ToString();
            textBox2.Text = ds.Tables[0].Rows[0]["SumofBook"].ToString();
            tbjdate.Text = ds.Tables[0].Rows[0]["SumofDate"].ToString();
            string sql3 = "select count(BrdetailID) as shuliang from BRDetail where ReaderXueHao='" + tbNO.Text + "'";
            DataSet ds1 = Library.ExecuteDataSet(sql3);
            tbdhow.Text = ds1.Tables[0].Rows[0]["shuliang"].ToString();
            int s = int.Parse(tbdhow.Text);
            if (s > 0)
            {
                int i2 = int.Parse(textBox2.Text);

                int outcome;
                outcome = i2 - s;
                textBox1.Text = outcome.ToString();
                
            }
          //  dateTimePicker3.Value = dateTimePicker1.Value.AddDays(Convert.ToInt32(tbjdate.Text, 10));
            dataGridView1.DataSource = Library.ExecuteDataSet("select * from BRDetail where ReaderXueHao='" + tbNO.Text + "'").Tables[0];
        }

        private void fBookBorrow_Load(object sender, EventArgs e)
        {
            tbNO.Focus();
        }

      

  
    }
}