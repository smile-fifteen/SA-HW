﻿namespace Library
{
    partial class fMain1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.用户功能ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据备份ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.事务处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借书管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.还书管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书证挂失处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读者管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书综合查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读者综合查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.读者借阅记录查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书馆书籍分类查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.本馆ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.超期罚款设定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户功能ToolStripMenuItem,
            this.事务处理ToolStripMenuItem,
            this.数据管理ToolStripMenuItem,
            this.查询统计ToolStripMenuItem,
            this.系统设置ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(455, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 用户功能ToolStripMenuItem
            // 
            this.用户功能ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.数据备份ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.用户功能ToolStripMenuItem.Name = "用户功能ToolStripMenuItem";
            this.用户功能ToolStripMenuItem.Size = new System.Drawing.Size(83, 18);
            this.用户功能ToolStripMenuItem.Text = "用户功能(&S)";
            // 
            // 数据备份ToolStripMenuItem
            // 
            this.数据备份ToolStripMenuItem.Name = "数据备份ToolStripMenuItem";
            this.数据备份ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.数据备份ToolStripMenuItem.Text = "数据备份(&B)";
            this.数据备份ToolStripMenuItem.Click += new System.EventHandler(this.数据备份ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.退出ToolStripMenuItem.Text = "退出(&X)";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 事务处理ToolStripMenuItem
            // 
            this.事务处理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.借书管理ToolStripMenuItem,
            this.还书管理ToolStripMenuItem,
            this.图书证挂失处理ToolStripMenuItem});
            this.事务处理ToolStripMenuItem.Name = "事务处理ToolStripMenuItem";
            this.事务处理ToolStripMenuItem.Size = new System.Drawing.Size(83, 18);
            this.事务处理ToolStripMenuItem.Text = "事务处理(&M)";
            // 
            // 借书管理ToolStripMenuItem
            // 
            this.借书管理ToolStripMenuItem.Name = "借书管理ToolStripMenuItem";
            this.借书管理ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.借书管理ToolStripMenuItem.Text = "借书管理(&B)";
            this.借书管理ToolStripMenuItem.Click += new System.EventHandler(this.借书管理ToolStripMenuItem_Click);
            // 
            // 还书管理ToolStripMenuItem
            // 
            this.还书管理ToolStripMenuItem.Name = "还书管理ToolStripMenuItem";
            this.还书管理ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.还书管理ToolStripMenuItem.Text = "还书管理(&R)";
            this.还书管理ToolStripMenuItem.Click += new System.EventHandler(this.还书管理ToolStripMenuItem_Click);
            // 
            // 图书证挂失处理ToolStripMenuItem
            // 
            this.图书证挂失处理ToolStripMenuItem.Name = "图书证挂失处理ToolStripMenuItem";
            this.图书证挂失处理ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.图书证挂失处理ToolStripMenuItem.Text = "图书证挂失处理(&L)";
            this.图书证挂失处理ToolStripMenuItem.Click += new System.EventHandler(this.图书证挂失处理ToolStripMenuItem_Click);
            // 
            // 数据管理ToolStripMenuItem
            // 
            this.数据管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图书管理ToolStripMenuItem,
            this.读者管理ToolStripMenuItem});
            this.数据管理ToolStripMenuItem.Name = "数据管理ToolStripMenuItem";
            this.数据管理ToolStripMenuItem.Size = new System.Drawing.Size(83, 18);
            this.数据管理ToolStripMenuItem.Text = "数据管理(&D)";
            // 
            // 图书管理ToolStripMenuItem
            // 
            this.图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            this.图书管理ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.图书管理ToolStripMenuItem.Text = "图书管理(&B)";
            this.图书管理ToolStripMenuItem.Click += new System.EventHandler(this.图书管理ToolStripMenuItem_Click);
            // 
            // 读者管理ToolStripMenuItem
            // 
            this.读者管理ToolStripMenuItem.Name = "读者管理ToolStripMenuItem";
            this.读者管理ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.读者管理ToolStripMenuItem.Text = "读者管理(&R)";
            this.读者管理ToolStripMenuItem.Click += new System.EventHandler(this.读者管理ToolStripMenuItem_Click);
            // 
            // 查询统计ToolStripMenuItem
            // 
            this.查询统计ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图书综合查询ToolStripMenuItem,
            this.读者综合查询ToolStripMenuItem,
            this.读者借阅记录查询ToolStripMenuItem,
            this.图书馆书籍分类查询ToolStripMenuItem});
            this.查询统计ToolStripMenuItem.Name = "查询统计ToolStripMenuItem";
            this.查询统计ToolStripMenuItem.Size = new System.Drawing.Size(83, 18);
            this.查询统计ToolStripMenuItem.Text = "查询统计(&Q)";
            // 
            // 图书综合查询ToolStripMenuItem
            // 
            this.图书综合查询ToolStripMenuItem.Name = "图书综合查询ToolStripMenuItem";
            this.图书综合查询ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.图书综合查询ToolStripMenuItem.Text = "图书综合查询(&B)";
            this.图书综合查询ToolStripMenuItem.Click += new System.EventHandler(this.图书综合查询ToolStripMenuItem_Click);
            // 
            // 读者综合查询ToolStripMenuItem
            // 
            this.读者综合查询ToolStripMenuItem.Name = "读者综合查询ToolStripMenuItem";
            this.读者综合查询ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.读者综合查询ToolStripMenuItem.Text = "读者综合查询(&R)";
            this.读者综合查询ToolStripMenuItem.Click += new System.EventHandler(this.读者综合查询ToolStripMenuItem_Click);
            // 
            // 读者借阅记录查询ToolStripMenuItem
            // 
            this.读者借阅记录查询ToolStripMenuItem.Name = "读者借阅记录查询ToolStripMenuItem";
            this.读者借阅记录查询ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.读者借阅记录查询ToolStripMenuItem.Text = "读者借阅记录查询(&Q)";
            this.读者借阅记录查询ToolStripMenuItem.Click += new System.EventHandler(this.读者借阅记录查询ToolStripMenuItem_Click);
            // 
            // 图书馆书籍分类查询ToolStripMenuItem
            // 
            this.图书馆书籍分类查询ToolStripMenuItem.Name = "图书馆书籍分类查询ToolStripMenuItem";
            this.图书馆书籍分类查询ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.图书馆书籍分类查询ToolStripMenuItem.Text = "图书馆书籍分类统计";
            this.图书馆书籍分类查询ToolStripMenuItem.Click += new System.EventHandler(this.图书馆书籍分类查询ToolStripMenuItem_Click);
            // 
            // 系统设置ToolStripMenuItem
            // 
            this.系统设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.本馆ToolStripMenuItem,
            this.超期罚款设定ToolStripMenuItem});
            this.系统设置ToolStripMenuItem.Name = "系统设置ToolStripMenuItem";
            this.系统设置ToolStripMenuItem.Size = new System.Drawing.Size(83, 18);
            this.系统设置ToolStripMenuItem.Text = "系统设置(&R)";
            // 
            // 本馆ToolStripMenuItem
            // 
            this.本馆ToolStripMenuItem.Name = "本馆ToolStripMenuItem";
            this.本馆ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.本馆ToolStripMenuItem.Text = "读者分类设定(&R)";
            this.本馆ToolStripMenuItem.Click += new System.EventHandler(this.本馆ToolStripMenuItem_Click);
            // 
            // 超期罚款设定ToolStripMenuItem
            // 
            this.超期罚款设定ToolStripMenuItem.Name = "超期罚款设定ToolStripMenuItem";
            this.超期罚款设定ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.超期罚款设定ToolStripMenuItem.Text = "超期罚款设定(&M)";
            this.超期罚款设定ToolStripMenuItem.Click += new System.EventHandler(this.超期罚款设定ToolStripMenuItem_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Image = global::Library.Properties.Resources.W95MBX01;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton9.Text = "退出";
            this.toolStripButton9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::Library.Properties.Resources._116;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton2.Text = "借书";
            this.toolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = global::Library.Properties.Resources._257;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton3.Text = "还书";
            this.toolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = global::Library.Properties.Resources._119;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(57, 48);
            this.toolStripButton4.Text = "证件挂失";
            this.toolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = global::Library.Properties.Resources._31;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(57, 48);
            this.toolStripButton5.Text = "图书管理";
            this.toolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.Image = global::Library.Properties.Resources._00;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(57, 48);
            this.toolStripButton6.Text = "读者管理";
            this.toolStripButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton9,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(455, 51);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "证件挂失";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(303, 151);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 2;
            this.textBox1.Visible = false;
            // 
            // fMain1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 587);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "fMain1";
            this.Text = "管理员登录";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fMain1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 用户功能ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据备份ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 事务处理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借书管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 还书管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书证挂失处理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读者管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书综合查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读者综合查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 读者借阅记录查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书馆书籍分类查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 本馆ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 超期罚款设定ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TextBox textBox1;
    }
}