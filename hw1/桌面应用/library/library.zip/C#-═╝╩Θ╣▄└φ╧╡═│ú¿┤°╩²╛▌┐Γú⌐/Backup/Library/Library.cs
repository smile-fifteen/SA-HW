using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Library
{
    class Library
    {
        private static string cnnString = "Data Source=.;Initial Catalog=Library;Integrated Security=True";
        //private static  string cnnString = "Data Source=127.0.0.1;Initial Catalog=SRSMS;User ID=sa;Password=sa";
        public static string chuanzhi;
        /// <summary>
        /// ���������ӡ�ɾ�����޸ĵȲ���
        /// </summary>
        /// <param name="sql">����SQL���</param>
        /// <returns>����Ӱ�������</returns>
        public static int ExecuteNoQuery(string sql)
        {
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand(sql, cnn);
            int returnValue = -1;
            try
            {
                cnn.Open();
                returnValue = cmd.ExecuteNonQuery();
            }
            catch
            {
                returnValue = -1;
            }
            return returnValue;
        }

        /// <summary>
        /// ��������ѯ����
        /// </summary>
        /// <param name="sql">����SQL���</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(string sql)
        {
            SqlDataAdapter sda = new SqlDataAdapter(sql, cnnString);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }
    }
}
