using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace Library
{
    public partial class fBookClassify : Form
    {
       
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fBookClassify instance = null;
        public static fBookClassify Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBookClassify();
                }
                return instance;
            }
        }
        private fBookClassify()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBookClassify_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void fBookclassify_Load(object sender, EventArgs e)
        {

        }

       

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (tbSearch.Text.Length <= 0)
            {
                MessageBox.Show("��ѯ��������Ϊ��", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (radioButton1.Checked)
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookID='" + tbSearch.Text + "'").Tables[0];
                
            }
            else
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookID='" + tbSearch.Text + "' and YNState='��'").Tables[0];
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {

        }
    }
}