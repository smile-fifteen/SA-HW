using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fPassword : Form
    {
               //����
        #region ����ʵ�ֵ���ģʽ
        private static fPassword instance = null;
        public static fPassword Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fPassword();
                }
                return instance;
            }
        }
        
        private fPassword()
        {
            InitializeComponent();
            instance = this;
           
        }
        private void fPassword_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void btCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

       

        private void btnOK_Click(object sender, EventArgs e)
        {
            string sql = "select ReaderPassword from Reader where ReaderXueHao= '" + tbUsername.Text + "'";
            DataSet ds = Library.ExecuteDataSet(sql);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["ReaderPassword"].ToString() == tbPassword.Text)
                {
                    if (tbNewpassword.Text == tbOK.Text)
                    {
                        string sql1 = "UPDATE Reader set ReaderPassword= '" + tbOK.Text + "'where ReaderXueHao= '" + tbUsername.Text + "'";
                        Library.ExecuteNoQuery(sql1);
                        MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Close();
                    }

                    else
                    {
                        MessageBox.Show("�������������ȷ�����벻����", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        tbPassword.Focus();
                       
                    }
                }

            }
            else
            {
                MessageBox.Show("��������벻��ȷ��", "�Ѻ���ʾ��");
                tbPassword.Focus();
               

            }
            
        }

        private void fPassword_Load(object sender, EventArgs e)
        {
            
        }

      
       
       
    }
}