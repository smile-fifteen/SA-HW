﻿namespace Library
{
    partial class fReaderManage
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ColumnReaderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderPassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderXueHao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderSex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderMajor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReaderType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnReaderID,
            this.ColumnReaderPassword,
            this.ColumnReaderXueHao,
            this.ColumnReaderName,
            this.ColumnReaderSex,
            this.ColumnReaderMajor,
            this.ColumnReaderClass,
            this.ColumnReaderType});
            this.dataGridView1.Location = new System.Drawing.Point(0, 54);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(625, 429);
            this.dataGridView1.TabIndex = 1;
            // 
            // ColumnReaderID
            // 
            this.ColumnReaderID.DataPropertyName = "ReaderID";
            this.ColumnReaderID.HeaderText = "读者ID";
            this.ColumnReaderID.Name = "ColumnReaderID";
            this.ColumnReaderID.ReadOnly = true;
            // 
            // ColumnReaderPassword
            // 
            this.ColumnReaderPassword.DataPropertyName = "ReaderPassword";
            this.ColumnReaderPassword.HeaderText = "读者密码";
            this.ColumnReaderPassword.Name = "ColumnReaderPassword";
            this.ColumnReaderPassword.ReadOnly = true;
            // 
            // ColumnReaderXueHao
            // 
            this.ColumnReaderXueHao.DataPropertyName = "ReaderXueHao";
            this.ColumnReaderXueHao.HeaderText = "读者学号";
            this.ColumnReaderXueHao.Name = "ColumnReaderXueHao";
            this.ColumnReaderXueHao.ReadOnly = true;
            // 
            // ColumnReaderName
            // 
            this.ColumnReaderName.DataPropertyName = "ReaderName";
            this.ColumnReaderName.HeaderText = "读者姓名";
            this.ColumnReaderName.Name = "ColumnReaderName";
            this.ColumnReaderName.ReadOnly = true;
            // 
            // ColumnReaderSex
            // 
            this.ColumnReaderSex.DataPropertyName = "ReaderSex";
            this.ColumnReaderSex.HeaderText = "读者性别";
            this.ColumnReaderSex.Name = "ColumnReaderSex";
            this.ColumnReaderSex.ReadOnly = true;
            // 
            // ColumnReaderMajor
            // 
            this.ColumnReaderMajor.DataPropertyName = "ReaderMajor";
            this.ColumnReaderMajor.HeaderText = "读者专业";
            this.ColumnReaderMajor.Name = "ColumnReaderMajor";
            this.ColumnReaderMajor.ReadOnly = true;
            // 
            // ColumnReaderClass
            // 
            this.ColumnReaderClass.DataPropertyName = "ReaderClass";
            this.ColumnReaderClass.HeaderText = "读者班级";
            this.ColumnReaderClass.Name = "ColumnReaderClass";
            this.ColumnReaderClass.ReadOnly = true;
            // 
            // ColumnReaderType
            // 
            this.ColumnReaderType.DataPropertyName = "ReaderType";
            this.ColumnReaderType.HeaderText = "读者类型";
            this.ColumnReaderType.Name = "ColumnReaderType";
            this.ColumnReaderType.ReadOnly = true;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::Library.Properties.Resources._236;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton1.Text = "添加";
            this.toolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::Library.Properties.Resources._233;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton2.Text = "修改";
            this.toolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = global::Library.Properties.Resources._063;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton3.Text = "删除";
            this.toolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = global::Library.Properties.Resources.W95MBX01;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton4.Text = "退出";
            this.toolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton5,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(627, 51);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = global::Library.Properties.Resources._145;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(36, 48);
            this.toolStripButton5.Text = "刷新";
            this.toolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // fReaderManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 495);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "fReaderManage";
            this.Text = "读者管理";
            this.Load += new System.EventHandler(this.fReaderManage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderPassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderXueHao;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderSex;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderMajor;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReaderType;

    }
}