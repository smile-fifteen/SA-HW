using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBookReturn : Form
    {
       
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fBookReturn instance = null;
        public static fBookReturn Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBookReturn();
                }
                return instance;
            }
        }
        private fBookReturn()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBookReturn_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ


        


        private void ˢ��ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tbdzNO.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select BookID,YingHuanDate from BRDetail where readerxuehao='" + tbdzNO.Text + "'").Tables[0];
        }

        private void fBookReturn_Load(object sender, EventArgs e)
        {
            string sql = "select fine from fine where ID='1'";
            DataSet ds = Library.ExecuteDataSet(sql);
            tbfine.Text = ds.Tables[0].Rows[0]["fine"].ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0 && dataGridView1.CurrentRow.Index >= 0)
            {
                
               
                DataGridViewRow dr = dataGridView1.CurrentRow;
                if (dr.Cells["ColumnYingHuanDate"].Value != null)
                {
                    dateTimePicker1.Value = DateTime.Parse(dr.Cells["ColumnYingHuanDate"].Value.ToString());
                }
                tbBookID.Text = dr.Cells["ColumnBookID"].Value.ToString();
                DateTime t1 = dateTimePicker1.Value;
                DateTime t2 = dateTimePicker2.Value;
                TimeSpan ts = t2 - t1;
                int d = ts.Days;
                tboverdate.Text = d.ToString();
                float fl1 = float.Parse(tboverdate.Text);
                float fl2 = float.Parse("0.1");
                float outcome;
                outcome = fl1 * fl2;
                tbmoney.Text = outcome.ToString();
 
            }
        }

   

        private void btncancle_Click(object sender, EventArgs e)
        {
            int s = int.Parse(tboverdate.Text);
            if (s > 0)
            {
                MessageBox.Show("�����ѳ��ڣ�����ɷ��", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                string sql = "Update Book set YNState='��' where BookID='" + tbBookID.Text + "'";
                Library.ExecuteDataSet(sql);
                Library.ExecuteNoQuery("delete from BRDetail where BookID='" + tbBookID.Text + "'");
                MessageBox.Show("�ѳɹ�����", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridView1.DataSource = Library.ExecuteDataSet("select BookID,YingHuanDate from BRDetail where readerxuehao='" + tbdzNO.Text + "'").Tables[0];
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            tboverdate.Text = "0";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    
    }
}