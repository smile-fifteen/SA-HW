using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fCardLost : Form
    {
        
         //����
        #region ����ʵ�ֵ���ģʽ
        private static fCardLost instance = null;
        public static fCardLost Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fCardLost();
                }
                return instance;
            }
        }
        private fCardLost()
        {
            InitializeComponent();
            instance = this;
        }
        private void fCardLost_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void ShowDetail()
        {
            
        }

        private void �˳�ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
           

            try
            {
                string sql = string.Empty;
                //string sql1 = string.Empty;
                if (this.Tag == null)
                {

                    sql = "INSERT INTO CardHistory(ReaderID,GuashiDate,BubanDate,FazhengDate) VALUES ('" + tbgNO.Text + "','" + 
                        dateTimePicker1.Value.ToShortDateString() + "','" + dateTimePicker2.Value.ToShortDateString() + "','" 
                        + dateTimePicker3.Value.ToShortDateString() + "')";

                }
                else
                {
                   ShowDialog();

                }

                Library.ExecuteNoQuery(sql);
                //Library.ExecuteNoQuery(sql1);
                MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from CardHistory where ReaderID='" + tbgNO.Text + "'").Tables[0];
              
            }
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
              
            }
            this.DialogResult = DialogResult.OK;
        }

       

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (tbgNO.Text.Length <= 0)
            {
                MessageBox.Show("��ѯ��������Ϊ��", "ϵͳ��ʾ:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                //dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader where ReaderXueHao='" + tbgNO.Text + "'").Tables[0];

            }
        }

        

        private void tbgNO_TextChanged(object sender, EventArgs e)
        {
            if (tbgNO.Text.Length == 8)
            {
                string sql = "select ReaderID,ReaderName,ReaderMajor,ReaderClass from Reader where ReaderXueHao='" + tbgNO.Text + "'";
                DataSet ds = Library.ExecuteDataSet(sql);
                tbgName.Text = ds.Tables[0].Rows[0]["ReaderName"].ToString();
                tbMaj.Text = ds.Tables[0].Rows[0]["ReaderMajor"].ToString();
                tbgClas.Text = ds.Tables[0].Rows[0]["ReaderClass"].ToString();

                
                }
            }

        private void fCardLost_Load(object sender, EventArgs e)
        {
            tbgNO.Focus();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tbgNO.Text = "";
            
            tbgName.Text = "";
            tbMaj.Text = "";
            tbgClas.Text = "";

        }
        }

    }
