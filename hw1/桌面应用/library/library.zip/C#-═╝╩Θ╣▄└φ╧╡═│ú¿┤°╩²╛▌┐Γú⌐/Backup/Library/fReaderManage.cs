using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fReaderManage : Form
    {
          //����
        #region ����ʵ�ֵ���ģʽ
        private static fReaderManage instance = null;
        public static fReaderManage Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fReaderManage();
                }
                return instance;
            }
        }
        private fReaderManage()
        {
            InitializeComponent();
            instance = this;
        }
        private void fReaderManage_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void ShowDetail()
        {
            
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            fReaderDetail frd = new fReaderDetail();
            frd.ShowDialog();

            if (frd.DialogResult == DialogResult.OK)
            {
                ShowDetail();
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //�޸�
            fReaderDetail frd = new fReaderDetail();
            frd.Tag = dataGridView1.CurrentRow;
            frd.ShowDialog();

            //ˢ��
            if (frd.DialogResult == DialogResult.OK)
            {
                ShowDetail();
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("�Ƿ�ȷ��ɾ��������¼��", "ϵͳ��ʾ��", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes)
            {
                Library.ExecuteNoQuery("delete from Reader where ReaderID=" + dataGridView1.CurrentRow.Cells["ColumnReaderID"].Value.ToString());
                ShowDetail();
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader").Tables[0];
        }

        private void fReaderManage_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader").Tables[0];
        }
    }
}