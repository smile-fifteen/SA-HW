﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace Library
{
    public partial class fbooksearch : Form
    {
        
         //属性
        #region 用来实现单例模式
        private static fbooksearch instance = null;
        public static fbooksearch Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fbooksearch();
                }
                return instance;
            }
        }
        private fbooksearch()
        {
            InitializeComponent();
            instance = this;
        }
        private void fbooksearch_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //窗体首次加载时


     

        private void fbooksearch_Load(object sender, EventArgs e)
        {
            //comboBox1.DisplayMember = "BookID";    
           // comboBox1.ValueMember = "BookPublish";
           //  comboBox1.DataSource = Library.ExecuteDataSet("select BookID,BookName,BookPublish from Book");
           // if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookID='" + tbSearch.Text + "'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookName='" + tbSearch.Text + "'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookPublish='" + tbSearch.Text + "'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 3)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookISBN='" + tbSearch.Text + "'").Tables[0];
                }
                else
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookAuthor='" + tbSearch.Text + "'").Tables[0];
                }

            }
            else
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookID='" + tbSearch.Text + "'and YNState='是'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookName='" + tbSearch.Text + "'and YNState='是'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookPublish='" + tbSearch.Text + "'and YNState='是'").Tables[0];
                }
                else if (comboBox1.SelectedIndex == 3)
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookISBN='" + tbSearch.Text + "'and YNState='是'").Tables[0];
                }
                else
                {
                    dataGridView1.DataSource = Library.ExecuteDataSet("select * from Book where BookAuthor='" + tbSearch.Text + "'and YNState='是'").Tables[0];
                }

            }
        }
    }
}