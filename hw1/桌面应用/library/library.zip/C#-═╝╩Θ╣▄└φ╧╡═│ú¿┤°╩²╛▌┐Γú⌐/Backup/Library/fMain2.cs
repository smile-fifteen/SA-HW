using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fMain2 : Form
    {
        public fMain2()
        {
            InitializeComponent();
        }

        private void �˳�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ԤԼToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fDate fd = fDate.Instance ;
            fd.MdiParent = this;
            fd.Show();
            fd.Activate();
            if (fd.WindowState == FormWindowState.Minimized)
            {
                fd.WindowState = FormWindowState.Normal;
            }
        }

        private void �޸�����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fPassword fp = fPassword.Instance ;
            fp.MdiParent = this;
            fp.Show();
            fp.Activate();
            if (fp.WindowState == FormWindowState.Minimized)
            {
                fp.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            fDate fd = fDate.Instance ;
            fd.MdiParent = this;
            fd.Show();
            fd.Activate();
            if (fd.WindowState == FormWindowState.Minimized)
            {
                fd.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            fPassword fp = fPassword.Instance;
            fp.MdiParent = this;
            fp.Show();
            fp.Activate();
            if (fp.WindowState == FormWindowState.Minimized)
            {
                fp.WindowState = FormWindowState.Normal;
            }
        }

        private void ��ѯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBookClassify fbc = fBookClassify.Instance ;
            fbc.MdiParent = this;
            fbc.Show();
            fbc.Activate();
            if (fbc.WindowState == FormWindowState.Minimized)
            {
                fbc.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            fBookClassify fbc = fBookClassify.Instance ;
            fbc.MdiParent = this;
            fbc.Show();
            fbc.Activate();
            if (fbc.WindowState == FormWindowState.Minimized)
            {
                fbc.WindowState = FormWindowState.Normal;
            }
        }

        private void fMain2_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
        }
    }
}