using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBackup : Form
    {
        //����
        #region ����ʵ�ֵ���ģʽ
        private static fBackup instance = null;
        public static fBackup Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fBackup();
                }
                return instance;
            }
        }
        private fBackup()
        {
            InitializeComponent();
            instance = this;
        }
        private void fBackup_FormClosed( object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ

        private void btCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void fBackup_Load(object sender, EventArgs e)
        {

        }

        private void btBackup_Click(object sender, EventArgs e)
        {
            string sql = @"backup Database MIS to disk='d:\MIS.bak'";
            Library.ExecuteDataSet(sql);
            MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}