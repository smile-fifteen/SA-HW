using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace Library
{
    public partial class fLogin2 : Form
    {
        public fLogin2()
        {
            InitializeComponent();
        }
        private int Count;
        private void fLogin_Load(object sender, EventArgs e)
        {
           
            Count = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select ReaderPassword from Reader where ReaderXueHao= '" + textBox1.Text + "'";
            DataSet ds = Library.ExecuteDataSet(sql);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["ReaderPassword"].ToString() == textBox2.Text)
                {
                    this.DialogResult = DialogResult.OK;
                }
               else
                {
                    MessageBox.Show("��������벻��ȷ��", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox2.Focus();
                    textBox2.SelectAll();
                    Count++;
                }

            }
                else
                {
                    MessageBox.Show("������û��������ڣ�", "�Ѻ���ʾ��");
                    textBox1.Focus();
                    textBox1.SelectAll();
                    Count++;

                }
                if (Count > 3)
                {
                    MessageBox.Show("��������������3�Σ�ϵͳ���Զ��˳���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Close();
                }
           
            }

        private void button2_Click(object sender, EventArgs e)
        {
        Application.Exit();
        }

        }

        
    }
