using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{

    public partial class fReaderDetail : Form
    {
            private void ShowDetail()
        {
            
        }
        public fReaderDetail()
        {
            InitializeComponent();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
           
            try
            {
                string sql = string.Empty;
                if (this.Tag == null)
                {
                    sql = "INSERT INTO Reader(readerpassword,readerxuehao,readername,readersex,ReaderMajor,ReaderClass,ReaderType) VALUES ( '" + 
                        tbdzpassword.Text + "','" + tbdzNO.Text + "','" + tbdzName.Text + "','";
                    if (rbMale.Checked)
                        sql += rbMale.Text;
                    else
                        sql += rbFemale.Text;
                    sql += "','" + tbdzzy.Text + "','" + tbdzbj.Text + "','" + tbType.Text + "')";

                }
                else
                {
                    sql = "Update Reader set readerpassword='" + tbdzpassword.Text + "',readerxuehao='" +
                        tbdzNO.Text + "',readername='" + tbdzName.Text + "',ReaderSex='";
                    if (rbMale.Checked)
                        sql += rbMale.Text;
                    else
                        sql += rbFemale.Text;
                    sql += "',ReaderMajor='" + tbdzzy.Text + "',ReaderClass='" + tbdzbj.Text + "',ReaderType='" + tbType.Text + "' where ReaderID='" + tbdzID.Text + "'";

                }

                Library.ExecuteNoQuery(sql);
                MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
              
            }
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            }
            this.DialogResult = DialogResult.OK;
        }

        private void tbdzpassword_Validating(object sender, CancelEventArgs e)
        {
            if (tbdzpassword.Text.Length == 0)
                errorProvider1.SetError(tbdzpassword, "������������룡");
            else
                errorProvider1.SetError(tbdzpassword, string.Empty);
        }

        private void tbdzNO_Validating(object sender, CancelEventArgs e)
        {
            if (tbdzNO.Text.Length == 0)
                errorProvider1.SetError(tbdzNO, "���������ѧ�ţ�");
            else
                errorProvider1.SetError(tbdzNO, string.Empty);
    
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tbdzID.Text = "";
            tbdzpassword.Text ="";
            tbdzNO.Text = "";
            tbdzName.Text = "";
            tbdzzy.Text = "";
            tbdzbj.Text = "";
            tbType.Text = "";
        }

        private void fReaderDetail_Load(object sender, EventArgs e)
        {
             
             if (this.Tag == null)
             {
                 //dateTimePicker1.Value = DateTime.Now.Subtract(new TimeSpan(20 * 365, 0, 0, 0, 0));
             }
             else
             {
                 DataGridViewRow dgvr = (DataGridViewRow)this.Tag;
                 tbdzID.Text = dgvr.Cells["ColumnReaderID"].Value.ToString();
                 tbdzpassword.Text = dgvr.Cells["ColumnReaderPassword"].Value.ToString();
                 tbdzNO.Text = dgvr.Cells["ColumnReaderXueHao"].Value.ToString();
                 tbdzName.Text = dgvr.Cells["ColumnReaderName"].Value.ToString();
                 if (dgvr.Cells["ColumnReaderSex"].Value != null && dgvr.Cells["ColumnReaderSex"].Value.ToString() == "��")
                     rbMale.Checked = true;
                 else
                     rbFemale.Checked = true;
                 tbdzzy.Text = dgvr.Cells["ColumnReaderMajor"].Value.ToString();
                 tbdzbj.Text = dgvr.Cells["ColumnReaderClass"].Value.ToString();
                 tbType.Text = dgvr.Cells["ColumnReaderType"].Value.ToString();


                 //if (!string.IsNullOrEmpty(dgvr.Cells["ColumnTime"].Value.ToString()));
                 //dateTimePicker1.Value = DateTime.Parse(dgvr.Cells["ColumnTime"].Value.ToString());
             }
                }

        private void tbdzID_TextChanged(object sender, EventArgs e)
        {
        
        } 
    }

    }
