using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fReaderSearch : Form
    {
          //����
        #region ����ʵ�ֵ���ģʽ
        private static fReaderSearch instance = null;
        public static fReaderSearch Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new fReaderSearch();
                }
                return instance;
            }
        }
        private fReaderSearch()
        {
            InitializeComponent();
            instance = this;
        }
        private void fReaderSearch_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }
        #endregion
        //�����״μ���ʱ
        

        private void fReaderSearch_Load(object sender, EventArgs e)
        {
            cmBClassify.SelectedIndex = 0;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (cmBClassify.SelectedIndex == 0)
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader where ReaderXueHao='" + tbSearch.Text + "' ").Tables[0];
            }
            else if (cmBClassify.SelectedIndex == 1)
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader where ReaderName='" + tbSearch.Text + "' ").Tables[0];
            }
            else if (cmBClassify.SelectedIndex == 2)
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader where ReaderClass='" + tbSearch.Text + "' ").Tables[0];
            }
            else
            {
                dataGridView1.DataSource = Library.ExecuteDataSet("select * from Reader where ReaderMajor='" + tbSearch.Text + "'").Tables[0];
            }
           
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            tbSearch.Text = "";
        }
    }
}