using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fBookDetail : Form
    {
        public fBookDetail()
        {
            InitializeComponent();
        }

       

       
        private void fBookDetail_Load(object sender, EventArgs e)
        {
            
        }

       

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Length == 0)
            {

                MessageBox.Show("������ͼ���ţ�", "ϵͳ��ʾ:");
                tbID.Focus();
                return;
            }

            if (tbISBN.Text.Length == 0)
            {

                MessageBox.Show("������ISBN��", "ϵͳ��ʾ:");
                tbISBN.Focus();
                return;
            }
            if (tbName.Text.Length == 0)
            {

                MessageBox.Show("������ͼ�����ƣ�", "ϵͳ��ʾ:");
                tbName.Focus();
                return;
            }

            try
            {
                string sql = string.Empty;
                if (this.Tag == null)
                {
                    sql = "INSERT INTO Book(BookID,ISBN,BookName,BookAuthor,BookCount,BookPublish,YNState,PublishTime,YNDate) VALUES ('" +
                        tbID.Text + "','" + tbISBN.Text + "','" + tbName.Text + "','" + tbAuthor.Text + "','" + tbCount.Text + "','" + tbPublish.Text + "','" + tbState.Text + "','" + 
                        dateTimePicker1.Value.ToShortDateString() + "','";
                    if (radioButton3.Checked)
                        sql += radioButton3.Text;
                    else
                        sql += radioButton4.Text;
                    sql += "')";


                }
                else
                {
                    sql = "Update Book set ISBN='" + tbISBN.Text + "',BookName='" + tbName.Text + "',BookAuthor='" +
                        tbAuthor.Text + "',BookCount='" + tbCount.Text + "',BookPublish='" + tbPublish.Text + "',YNState='" + tbState.Text + "',YNDate='";
                    if (radioButton3.Checked)
                        sql += radioButton3.Text;
                    else
                        sql += radioButton4.Text;
                    sql += "',PublishTime='" + dateTimePicker1.Value.ToShortDateString() + "' where BookID='" + tbID.Text + "'";
                }
                Library.ExecuteNoQuery(sql);
                MessageBox.Show("�����ɹ���", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch
            {
                MessageBox.Show("��������", "ϵͳ��ʾ��", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void fBookDetail_Load_1(object sender, EventArgs e)
        {
            if (this.Tag == null)
            {
                dateTimePicker1.Value = DateTime.Now.Subtract(new TimeSpan(20 * 365, 0, 0, 0, 0));
            }
            else
            {
                DataGridViewRow dgvr = (DataGridViewRow)this.Tag;
                tbID.Text = dgvr.Cells["ColumnBookID"].Value.ToString();
                tbISBN.Text = dgvr.Cells["ColumnISBN"].Value.ToString();
                tbName.Text = dgvr.Cells["ColumnName"].Value.ToString();
                tbAuthor.Text = dgvr.Cells["ColumnAuthor"].Value.ToString();
                tbCount.Text = dgvr.Cells["ColumnCount"].Value.ToString();
                tbPublish.Text = dgvr.Cells["ColumnPublish"].Value.ToString();
                tbState.Text = dgvr.Cells["ColumnState"].Value.ToString();
                if (dgvr.Cells["ColumnDate"].Value != null && dgvr.Cells["ColumnDate"].Value.ToString() == "δԤ��")
                    radioButton3.Checked = true;
                else
                    radioButton4.Checked = true;
                if (!string.IsNullOrEmpty(dgvr.Cells["ColumnTime"].Value.ToString()))
                    dateTimePicker1.Value = DateTime.Parse(dgvr.Cells["ColumnTime"].Value.ToString());
            }
        }

      
    }
}