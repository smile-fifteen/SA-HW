using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Library
{
    public partial class fMain1 : Form
    {
        
        public fMain1()
        {
            
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void fMain1_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;

            textBox1.Text = Library.chuanzhi;
            if (textBox1.Text == "01")
            {
                �û�����ToolStripMenuItem.Visible = true;
                ���ݹ���ToolStripMenuItem.Visible = true;
                ��ѯͳ��ToolStripMenuItem.Visible = true;
                ������ToolStripMenuItem.Visible = true;
                ϵͳ����ToolStripMenuItem.Visible = true;
                toolStripButton9.Visible = true;
                toolStripButton2.Visible = true;
                toolStripButton3.Visible = true;
                toolStripButton4.Visible = true;
                toolStripButton5.Visible = true;
                toolStripButton6.Visible = true;

            }
            else 
            {
                �û�����ToolStripMenuItem.Visible = false;
                ���ݹ���ToolStripMenuItem.Visible = false;
                toolStripButton5.Visible = false;
                toolStripButton6.Visible = false;
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

       
      

        private void ���ݱ���ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBackup fbu = fBackup.Instance;
            fbu.MdiParent = this;
            fbu.Show();
            fbu.Activate();
            if (fbu.WindowState == FormWindowState.Minimized)
            {
                fbu.WindowState = FormWindowState.Normal;
            }
        }

        private void �˳�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBookBorrow fbb = fBookBorrow.Instance ;
            fbb.MdiParent = this;
            fbb.Show();
            fbb.Activate();
            if (fbb.WindowState == FormWindowState.Minimized)
            {
                fbb.WindowState = FormWindowState.Normal;
            }
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBookReturn fbr = fBookReturn.Instance;
            fbr.MdiParent = this;
            fbr.Show();
            fbr.Activate();
            if (fbr.WindowState == FormWindowState.Minimized)
            {
                fbr.WindowState = FormWindowState.Normal;
            }
        }

        private void ͼ��֤��ʧ����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fCardLost fcl = fCardLost.Instance;
            fcl.MdiParent = this;
            fcl.Show();
            fcl.Activate();
            if (fcl.WindowState == FormWindowState.Minimized)
            {
                fcl.WindowState = FormWindowState.Normal;
            }
        }

        private void ͼ�����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBook fb = fBook.Instance;
            fb.MdiParent = this;
            fb.Show();
            fb.Activate();
            if (fb.WindowState == FormWindowState.Minimized)
            {
                fb.WindowState = FormWindowState.Normal;
            }
        }

        private void ���߹���ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReaderManage frm = fReaderManage.Instance;
            frm.MdiParent = this;
            frm.Show();
            frm.Activate();
            if (frm.WindowState == FormWindowState.Minimized)
            {
                frm.WindowState = FormWindowState.Normal;
            }
        }

        private void ͼ���ۺϲ�ѯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fbooksearch fbs = fbooksearch.Instance;
            fbs.MdiParent = this;
            fbs.Show();
            fbs.Activate();
            if (fbs.WindowState == FormWindowState.Minimized)
            {
                fbs.WindowState = FormWindowState.Normal;
            }
        }

        private void �����ۺϲ�ѯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReaderSearch frs = fReaderSearch.Instance;
            frs.MdiParent = this;
            frs.Show();
            frs.Activate();
            if (frs.WindowState == FormWindowState.Minimized)
            {
                frs.WindowState = FormWindowState.Normal;
            }
        }

        private void ���߽��ļ�¼��ѯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBorrowList fbl = fBorrowList.Instance;
            fbl.MdiParent = this;
            fbl.Show();
            fbl.Activate();
            if (fbl.WindowState == FormWindowState.Minimized)
            {
                fbl.WindowState = FormWindowState.Normal;
            }
        }

     

        private void ͼ����鼮�����ѯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fBookClassify fbc = fBookClassify.Instance;
            fbc.MdiParent = this;
            fbc.Show();
            fbc.Activate();
            if (fbc.WindowState == FormWindowState.Minimized)
            {
                fbc.WindowState = FormWindowState.Normal;
            }
        }

        private void ����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fReaderClassify frc = fReaderClassify.Instance;
            frc.MdiParent = this;
            frc.Show();
            frc.Activate();
            if (frc.WindowState == FormWindowState.Minimized)
            {
                frc.WindowState = FormWindowState.Normal;
            }
        }

        

        private void ���ڷ����趨ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fFine ff = fFine.Instance;
            ff.MdiParent = this;
            ff.Show();
            ff.Activate();
            if (ff.WindowState == FormWindowState.Minimized)
            {
                ff.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            fBookBorrow fbb = fBookBorrow.Instance;
            fbb.MdiParent = this;
            fbb.Show();
            fbb.Activate();
            if (fbb.WindowState == FormWindowState.Minimized)
            {
                fbb.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            fBookReturn fbr = fBookReturn.Instance;
            fbr.MdiParent = this;
            fbr.Show();
            fbr.Activate();
            if (fbr.WindowState == FormWindowState.Minimized)
            {
                fbr.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            fCardLost fcl = fCardLost.Instance ;
            fcl.MdiParent = this;
            fcl.Show();
            fcl.Activate();
            if (fcl.WindowState == FormWindowState.Minimized)
            {
                fcl.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            fBook fb = fBook.Instance;
            fb.MdiParent = this;
            fb.Show();
            fb.Activate();
            if (fb.WindowState == FormWindowState.Minimized)
            {
                fb.WindowState = FormWindowState.Normal;
            }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            fReaderManage frm = fReaderManage.Instance;
            frm.MdiParent = this;
            frm.Show();
            frm.Activate();
            if (frm.WindowState == FormWindowState.Minimized)
            {
                frm.WindowState = FormWindowState.Normal;
            }
        }
    }
}